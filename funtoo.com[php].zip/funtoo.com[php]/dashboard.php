<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="bg.css">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>DASHBOARDS</title>
    </head>
    <body>
        <h1>Welcome Admin!</h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:self.close()">Logout</a>
        <ul>
            <li><a href="regestered.php" target="_blank">Our Registered Users</a></li>
            <li><a href="viewfeedback.php"target="_blank">View Feedback from users</a></li>
            <li><a href="prod.php"target="_blank">View Products</a></li>
            <li><a href="orders.php"target="_blank">View Current Orders</a></li>
        
        </ul>
        
    </body>
</html>
