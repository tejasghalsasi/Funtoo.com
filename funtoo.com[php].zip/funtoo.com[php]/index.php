<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">     
    <title>FUNTOO SHOPPPING MEGA STORE</title>
    </head>
    <frameset rows="15%,85%" border="0">
     <frame src="t.html">
    <frameset cols="10%,90%" border="0" >
        <frame src="left.php">
        <frame src="right.html">
     </frameset>
 </frameset>
    <body>
</body>
</html>
