<html>
    <head>
        <link rel="stylesheet" type="text/css" href="bg.css">
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Welcome Customer</title>
    </head>
    <body>
        <ol>
            
            <li>Check out our phone collection:<a href="prod.php" target="_blank"> click here!</a></li>
            <li> To place an order:<a href="place.php" target="_blank"> click here!</a></li>
            <li><a href="javascript:self.close()">Logout</a></li>
        </ol>

    </body>
    
</html>
